package com.lau.tech_newsapprawad;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase database;
    ArrayAdapter adapter;
    ArrayList<String> articleContent = new ArrayList<>();
    ArrayList<String> articleName = new ArrayList<>();

    public class DownloadTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            String res = "";
            URL url;
            HttpURLConnection connection = null;
            try {
                url = new URL(urls[0]);
                connection = (HttpURLConnection) url.openConnection();
                InputStream in = connection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                int data = reader.read();

                while (data != -1) {
                    char current = (char) data;
                    res += current;
                    data = reader.read();
                }

                JSONArray array = new JSONArray(res);
                int numTitles = 20;

                if (array.length() < 20) {
                    numTitles = array.length();
                }

                database.execSQL("DELETE FROM MyArticlesDB");

                for (int i = 0; i < numTitles; i++) {
                    String info = "";
                    String id = array.getString(i);
                    url = new URL("https://hacker-news.firebaseio.com/v0/item/" + id + ".json?print=pretty");
                    connection = (HttpURLConnection) url.openConnection();
                    in = connection.getInputStream();
                    reader = new InputStreamReader(in);
                    data = reader.read();

                    while (data != -1) {
                        char current = (char) data;
                        info += current;
                        data = reader.read();
                    }

                    JSONObject object = new JSONObject(info);

                    if (!object.isNull("articleTitle") && !object.isNull("url")) {
                        String cont = "";
                        String title = object.getString("articleTitle");
                        String URL = object.getString("url");
                        url = new URL(URL);
                        connection = (HttpURLConnection) url.openConnection();
                        in = connection.getInputStream();
                        reader = new InputStreamReader(in);
                        data = reader.read();

                        while (data != -1) {
                            char curr = (char) data;
                            cont += curr;
                            data = reader.read();
                        }

                        String sql = "INSERT INTO MyArticlesDB (articleId, articleTitle, articleContent) VALUES (?, ?, ?)";
                        SQLiteStatement statement = database.compileStatement(sql);
                        statement.bindString(1, id);
                        statement.bindString(2, title);
                        statement.bindString(3, cont);
                        statement.execute();

                    }
                }
                return res;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    public void changeMyArticles() {
        Cursor cursor = database.rawQuery("SELECT * FROM articles", null);
        int CI = cursor.getColumnIndex("articleContent");
        int TI = cursor.getColumnIndex("articleTitle");

        if (cursor.moveToFirst()) {
            articleName.clear();
            articleContent.clear();
            do {
                articleName.add(cursor.getString(TI));
                articleContent.add(cursor.getString(CI));
            } while (cursor.moveToNext());
            adapter.notifyDataSetChanged();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        database = this.openOrCreateDatabase("MyArticlesDB", MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS articles (id INTEGER PRIMARY KEY, articleId, INTEGER, articleTitle VARCHAR, articleContent VARCHAR)");
        DownloadTask task = new DownloadTask();

        try {
            task.execute("https://hacker-news.firebaseio.com/v0/topstories.json?print=pretty");
        }
        catch (Exception e) {
        }

        ListView List = findViewById(R.id.list);
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, articleName);
        List.setAdapter(adapter);
        List.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(getApplicationContext(), ArticleActivity.class);
                i.putExtra("ArticleContent", articleContent.get(position));
                startActivity(i);
            }
        });

        changeMyArticles();

    }
}
